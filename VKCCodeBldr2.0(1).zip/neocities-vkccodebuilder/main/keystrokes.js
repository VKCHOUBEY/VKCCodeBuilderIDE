var keycomb=document.querySelector('#keyoptions');

function keystrokeFn()
{
document.querySelector("#maindoc").style.visibility="visible";

keycomb.style.visibility="visible";
}

var clBtn=document.querySelector('#closebtn')

clBtn.onclick=function(){
document.querySelector('#maindoc').style.visibility="hidden";
document.querySelector('#keyoptions').style.visibility="hidden";

}



clBtn.onmouseover=function(){
  clBtn.style.opacity='1';
}

clBtn.onmouseout=function(){
  clBtn.style.opacity='0.8'
}


//Functional Blocks//



  

function saveTextAsFile()
{
var fileNameToSaveAs = document.getElementById("inputFileNameToSaveAs");
var xcodeparam=document.getElementById("code").value;

if(fileNameToSaveAs.value=="")
{
fileNameToSaveAs.style.backgroundColor="#f7f7f7";
fileNameToSaveAs.placeholder="  Error:File name can't be null";
document.codebuilderfrm.filename.focus();
}


else
{

	var downloadLink = document.createElement("a");
	downloadLink.download = fileNameToSaveAs.value+"_VKCCodeBuilder"+'.html';
	downloadLink.target="_self";
	downloadLink.innerHTML = "";
	fileNameToSaveAs.placeholder="  Enter file name to save...";
	fileNameToSaveAs.style.backgroundColor="#ffffff";

	
	
	downloadLink.href="data:text/html;charset=utf-8,"+encodeURIComponent(xcodeparam);
		
		
     document.body.appendChild(downloadLink);
	 
     downloadLink.click();

		
	
	}





	
}


function clrInputScreen()
{
document.getElementById('code').value="";
intMaz(); 

sessionOffContent();
};



function openXCode()
{
var xcodeparam=document.getElementById("code").value;

window.open("data:text/html;charset=utf-8,<p><a href="+"javascript:window.close()"+">Return to IDE</a></p>"+encodeURIComponent(xcodeparam));

}


function RunWithJS()

{
document.querySelector("#errorchk").innerHTML="";
document.querySelector("#y").style.backgroundColor="lightsteelblue";
document.querySelector("#n").style.backgroundColor="";

document.getElementById("DUMMY").style.width="auto";
document.getElementById("DUMMY").style.height="auto";

var prg=document.getElementById('code').value;


$('#DUMMY').html("<iframe scrolling=yes style='position:absolute;width:700px;height:600px;border:1px dashed;color:steelblue' id='resultxcode'></iframe>");

document.getElementById("resultxcode").srcdoc="<HTML><head><meta charset='UTF-8'></head><body>"+prg+"</body></html>"
 
}



